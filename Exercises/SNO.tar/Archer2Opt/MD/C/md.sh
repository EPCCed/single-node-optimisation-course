#!/bin/bash
#SBATCH --job-name=MD
#SBATCH --time=0:20:0
#SBATCH --nodes=1
#SBATCH --ntasks-per-core=1
#SBATCH --exclusive
#SBATCH --partition=standard
#SBATCH --qos=standard
# Replace XXX with your project code (e.g. ta013)
#SBATCH --account=XXX


srun -n 1 ./MD
