#!/bin/bash
#SBATCH --job-name=dstreams
#SBATCH --time=0:20:0
#SBATCH --nodes=1
#SBATCH --ntasks-per-core=1
#SBATCH --exclusive
#SBATCH --partition=standard
#SBATCH --qos=standard
#SBATCH --account=XXXX

module load epcc-job-env
module load xthi
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:`pwd`/mxml/3.1/lib
export OMP_NUM_THREADS=1


srun -c 1 -n 16 --hint=nomultithread --distribution=block:block xthi
srun -c 1 -n 16 --hint=nomultithread --distribution=block:block ./distributed_streams

