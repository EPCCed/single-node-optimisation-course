#!/bin/bash
#SBATCH --job-name=vh1
#SBATCH --nodes=1
#SBATCH --tasks-per-node=128
#SBATCH --cpus-per-task=1
#SBATCH --time=0:20:0
#SBATCH --partition=standard
#SBATCH --qos=standard
#SBATCH --account=XXX

module load epcc-job-env

EXE=vh1-mpi-cray
# Turn of the stop message from the Cray compiler
export NO_STOP_MESSAGE=1

# Change to the same directory that qsub was run in
ROOTDIR=${SLURM_SUBMIT_DIR}
RUNDIR=${ROOTDIR}/${SLURM_JOB_ID}
BINDIR=${ROOTDIR}/../bin

# Set the number of ranks to use
NPROC=128
NTASK=128

# Create the output directory
mkdir -p ${RUNDIR}/output
cd ${RUNDIR}
cp ${ROOTDIR}/indat ${RUNDIR}
cp ${BINDIR}/${EXE} ${RUNDIR}

# Launch the application in parallel with NPROCS ranks 
srun ./${EXE}

# Cat the output file to screen
if [[ -e output/NCState.hst ]]; then
  cat output/NCState.hst
fi
